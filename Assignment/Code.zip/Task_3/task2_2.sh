#!/bin/bash
repls=(
    "lru"
    "srrip" # this is srrip-hp
    "srripfp"
    "drrip"
    "random"
)

# Compile
for repl in "${repls[@]}";
do
    echo "Running command: ./build_champsim.sh bimodal no no no no $repl 1 4 -1 false"
    ./build_champsim.sh bimodal no no no no $repl 1 4 -1 0
done

# Simulation
traces=(
    "603.bwaves_s-3699B.champsimtrace.xz"
    "648.exchange2_s-1699B.champsimtrace.xz"
    "638.imagick_s-10316B.champsimtrace.xz"
    "644.nab_s-5853B.champsimtrace.xz"
    "627.cam4_s-573B.champsimtrace.xz"
    "600.perlbench_s-210B.champsimtrace.xz"
    "623.xalancbmk_s-700B.champsimtrace.xz"
    "654.roms_s-842B.champsimtrace.xz"
    "625.x264_s-18B.champsimtrace.xz"
    "607.cactuBSSN_s-2421B.champsimtrace.xz"
    "631.deepsjeng_s-928B.champsimtrace.xz"
    "628.pop2_s-17B.champsimtrace.xz"
    "649.fotonik3d_s-1176B.champsimtrace.xz"
)

for repl in "${repls[@]}"; do
    for trace in "${traces[@]}"; do
        echo "Running: $repl $trace"
        ./run_champsim.sh bimodal-no-no-no-no-${repl}-1core-4MB--1-0 50 200 "$trace"
    done
done
