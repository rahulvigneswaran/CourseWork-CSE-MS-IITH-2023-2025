# Assignement 1

>  For changing parameters inside each task, I have changed the scripts in such a way the hyperparams are taken as arguments.

## How to run
Inside each folder run, 
- `task2_1.sh` for the 1st part of task 2.
- `task2_2.sh` for the 2nd part of task 2.
- `task3.sh` for the 1st part of task 2.
- `task4.sh` for the 1st part of task 2.

## How to collect results and plot
To collate the results into csv and plot, check the ipython notebooks inside each folder with the corresponding task names. The already collated results are available at [this link](https://docs.google.com/spreadsheets/d/1zvanMj2k1QR-_KUKsNWw29bfyBnAlHOe8VhzvOco24k/edit?usp=sharing).